export class ConstantPage {


    GET_MARKSHEET_URL = 'https://ccbst.org/CCBST-LIVE/api/v1/marksheet'
    // POST_LOGIN_URL = 'https://ccbst.org/CCBST-LIVE/api/v1/login'
    // POST_REFERRAL_URL = 'https://ccbst.org/CCBST-LIVE/api/v1/referral-student'


}